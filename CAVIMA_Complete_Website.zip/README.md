# CAVIMA Complete Professional Website

## Included
index.html
about.html
agriculture.html
training.html
research.html
climate.html
community.html
partnerships.html
gallery.html
contact.html
css/style.css
js/script.js
assets/

## GitHub Pages
Upload the CONTENTS of this folder into the ROOT of your GitHub repository. `index.html` must be in the repository root. Commit the changes. Then check Settings -> Pages.

## CAVIMA contact details used
Phone: +254 726 743458
Phone: +254 788 659777
Email: cavima2026t@gmail.com
Location: Ntujia Village, Tharaka Nithi County, Kenya

## Photos
The pages reference CAVIMA photo filenames in assets/. If your existing files use different names, rename them to match the names referenced in the HTML, or edit the HTML filenames.

## Accuracy
The site deliberately avoids invented statistics, named partners, awards, funding claims or unsupported achievements. Add confirmed facts when available.
