
document.addEventListener("DOMContentLoaded",()=>{
 const menu=document.querySelector(".menu"), links=document.querySelector(".links");
 if(menu&&links){menu.addEventListener("click",()=>{links.classList.toggle("show");links.style.display=links.classList.contains("show")?"flex":"";links.style.flexDirection="column";links.style.position="absolute";links.style.top="80px";links.style.left="0";links.style.right="0";links.style.padding="18px 5%";links.style.background="#fff";links.style.borderBottom="1px solid #d9e9df"})}
 document.querySelectorAll("[data-year]").forEach(e=>e.textContent=new Date().getFullYear());
 const file=location.pathname.split("/").pop()||"index.html";
 document.querySelectorAll(".links a[data-page]").forEach(a=>{if(a.dataset.page===file)a.classList.add("active")});
});
